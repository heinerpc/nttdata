package com.nttdata.restfull.controller;

import com.nttdata.restfull.dao.PhonesDao;
import com.nttdata.restfull.dao.UsersDao;
import com.nttdata.restfull.model.Phones;
import com.nttdata.restfull.model.Users;
import com.nttdata.restfull.service.JwtUtilService;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/restfull/v1")
public class UserController {

    @Autowired
    private PhonesDao phonesDao;

    @Autowired
    private UsersDao usersDao;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    UserDetailsService usuarioDetailsService;

    @Autowired
    private JwtUtilService jwtUtilService;

    @PostMapping(path = "/crearusuario", produces = "application/json")
    public ResponseEntity<Users> crearUsuario(@RequestBody Users usuario) {

        usuario.setId(UUID.randomUUID());
        for (Phones listPhones : usuario.getPhones()) {
            listPhones.setId(UUID.randomUUID());
        }
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(usuario.getId(), usuario.getName()));

        UserDetails userDetails = usuarioDetailsService.loadUserByUsername(usuario.getName());
        String jwt = jwtUtilService.generateToken(userDetails);
        usuario.setToken(jwt);
        phonesDao.saveAll(usuario.getPhones());
        usuario.setCreated(obtenerFecha());
        usuario.setModified(obtenerFecha());
        usuario.setLastLogin(obtenerFecha());
        usuario.setSactive(true);
        usersDao.save(usuario);

        return ResponseEntity.status(HttpStatus.CREATED).body(usuario);

    }

    private String obtenerFecha() {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        String fechaComoCadena = sdf.format(new Date());
        return fechaComoCadena;

    }

}
