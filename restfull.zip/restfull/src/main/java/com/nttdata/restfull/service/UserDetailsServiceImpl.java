package com.nttdata.restfull.service;

import java.util.List;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Usuario usuario = (Usuario) getById(username);

        if (usuario == null) {
            throw new UsernameNotFoundException(username);
        }

        return User.withUsername(username).password(usuario.getPassword()).roles(usuario.getRol())
                .build();
    }

    public class Usuario {

        @Override
        public String toString() {
            return "Usuario [username=" + username + ", password=" + password + ", rol=" + rol
                    + "]";
        }

        private String username;
        private String password;
        private String rol;

        public Usuario(String username, String password, String rol) {
            super();
            this.username = username;
            this.password = password;
            this.rol = rol;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public String getRol() {
            return rol;
        }

        public void setRoles(String rol) {
            this.rol = rol;
        }

    };

    private Object getById(String username) {

        String password = "$2a$10$56VCAiApLO8NQYeOPiu2De/EBC5RWrTZvLl7uoeC3r7iXinRR1iiq";
        Usuario juan = new Usuario("heinerpc", password, "USER");
        List<Usuario> usuarios = List.of(juan);

        return usuarios.stream().filter(e -> e.getUsername().equals(username)).findFirst()
                .orElse(null);
    }
}
