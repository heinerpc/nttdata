package com.nttdata.restfull.dao;

import com.nttdata.restfull.model.Phones;
import java.util.UUID;
import org.springframework.data.repository.CrudRepository;

public interface PhonesDao extends CrudRepository<Phones, UUID> {

}
