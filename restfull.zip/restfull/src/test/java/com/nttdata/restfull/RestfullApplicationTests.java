package com.nttdata.restfull;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfullApplicationTests {

	@Test
	void contextLoads() {
	}

}
